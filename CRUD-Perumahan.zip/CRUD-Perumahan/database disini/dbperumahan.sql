-- phpMyAdmin SQL Dump
-- version 4.8.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 03, 2020 at 12:27 AM
-- Server version: 10.1.37-MariaDB
-- PHP Version: 7.3.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `dbperumahan`
--

-- --------------------------------------------------------

--
-- Stand-in structure for view `q_laporan`
-- (See below for the actual view)
--
CREATE TABLE `q_laporan` (
`id_customer` varchar(10)
,`nama_customer` varchar(30)
,`nama_fasilitas` varchar(30)
,`biaya_fasilitas` varchar(20)
,`id_transaksi` varchar(10)
,`jmlhbeli_fasilitas` int(1)
,`jumlahbeli_rumah` int(1)
,`ttlhrgrumah` bigint(20)
,`uang_muka` int(20)
,`hutang` double
,`hutangbunga` double
,`ttlhutang` double
,`jangka_kredit` int(4)
,`jngkakreditbulan` bigint(13)
,`angsuranperbulan` double
);

-- --------------------------------------------------------

--
-- Table structure for table `tbcustomer`
--

CREATE TABLE `tbcustomer` (
  `id_customer` varchar(10) NOT NULL,
  `nama_customer` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbcustomer`
--

INSERT INTO `tbcustomer` (`id_customer`, `nama_customer`) VALUES
('10001', 'Ekabasa Solusindo');

-- --------------------------------------------------------

--
-- Table structure for table `tbfasilitas`
--

CREATE TABLE `tbfasilitas` (
  `id_fasilitas` varchar(10) NOT NULL,
  `nama_fasilitas` varchar(30) NOT NULL,
  `biaya_fasilitas` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbfasilitas`
--

INSERT INTO `tbfasilitas` (`id_fasilitas`, `nama_fasilitas`, `biaya_fasilitas`) VALUES
('IF001', 'Terali', '600000'),
('IF002', 'Kitchen Set', '2000000'),
('IF003', 'Keran', '6000');

-- --------------------------------------------------------

--
-- Table structure for table `tbtransaksi`
--

CREATE TABLE `tbtransaksi` (
  `id_transaksi` varchar(10) NOT NULL,
  `id_customer` varchar(11) NOT NULL,
  `id_fasilitas` varchar(10) NOT NULL,
  `jumlahbeli_rumah` int(1) NOT NULL,
  `jmlhbeli_fasilitas` int(1) NOT NULL,
  `uang_muka` int(20) NOT NULL,
  `jangka_kredit` int(4) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbtransaksi`
--

INSERT INTO `tbtransaksi` (`id_transaksi`, `id_customer`, `id_fasilitas`, `jumlahbeli_rumah`, `jmlhbeli_fasilitas`, `uang_muka`, `jangka_kredit`) VALUES
('IT01', '10001', 'IF001', 1, 1, 110000000, 1);

-- --------------------------------------------------------

--
-- Structure for view `q_laporan`
--
DROP TABLE IF EXISTS `q_laporan`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `q_laporan`  AS  select `tbcustomer`.`id_customer` AS `id_customer`,`tbcustomer`.`nama_customer` AS `nama_customer`,`tbfasilitas`.`nama_fasilitas` AS `nama_fasilitas`,`tbfasilitas`.`biaya_fasilitas` AS `biaya_fasilitas`,`tbtransaksi`.`id_transaksi` AS `id_transaksi`,`tbtransaksi`.`jmlhbeli_fasilitas` AS `jmlhbeli_fasilitas`,`tbtransaksi`.`jumlahbeli_rumah` AS `jumlahbeli_rumah`,(130000000 * `tbtransaksi`.`jumlahbeli_rumah`) AS `ttlhrgrumah`,`tbtransaksi`.`uang_muka` AS `uang_muka`,(((130000000 * `tbtransaksi`.`jumlahbeli_rumah`) + (`tbtransaksi`.`jmlhbeli_fasilitas` * `tbfasilitas`.`biaya_fasilitas`)) - `tbtransaksi`.`uang_muka`) AS `hutang`,(((((130000000 * `tbtransaksi`.`jumlahbeli_rumah`) + (`tbtransaksi`.`jmlhbeli_fasilitas` * `tbfasilitas`.`biaya_fasilitas`)) - `tbtransaksi`.`uang_muka`) * 14) / 100) AS `hutangbunga`,((((130000000 * `tbtransaksi`.`jumlahbeli_rumah`) + (`tbtransaksi`.`jmlhbeli_fasilitas` * `tbfasilitas`.`biaya_fasilitas`)) - `tbtransaksi`.`uang_muka`) + (((((130000000 * `tbtransaksi`.`jumlahbeli_rumah`) + (`tbtransaksi`.`jmlhbeli_fasilitas` * `tbfasilitas`.`biaya_fasilitas`)) - `tbtransaksi`.`uang_muka`) * 14) / 100)) AS `ttlhutang`,`tbtransaksi`.`jangka_kredit` AS `jangka_kredit`,(`tbtransaksi`.`jangka_kredit` * 12) AS `jngkakreditbulan`,(((((130000000 * `tbtransaksi`.`jumlahbeli_rumah`) + (`tbtransaksi`.`jmlhbeli_fasilitas` * `tbfasilitas`.`biaya_fasilitas`)) - `tbtransaksi`.`uang_muka`) + (((((130000000 * `tbtransaksi`.`jumlahbeli_rumah`) + (`tbtransaksi`.`jmlhbeli_fasilitas` * `tbfasilitas`.`biaya_fasilitas`)) - `tbtransaksi`.`uang_muka`) * 14) / 100)) / (`tbtransaksi`.`jangka_kredit` * 12)) AS `angsuranperbulan` from ((`tbtransaksi` join `tbcustomer` on((`tbtransaksi`.`id_customer` = `tbcustomer`.`id_customer`))) join `tbfasilitas` on((`tbtransaksi`.`id_fasilitas` = `tbfasilitas`.`id_fasilitas`))) ;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tbcustomer`
--
ALTER TABLE `tbcustomer`
  ADD PRIMARY KEY (`id_customer`);

--
-- Indexes for table `tbfasilitas`
--
ALTER TABLE `tbfasilitas`
  ADD PRIMARY KEY (`id_fasilitas`);

--
-- Indexes for table `tbtransaksi`
--
ALTER TABLE `tbtransaksi`
  ADD PRIMARY KEY (`id_transaksi`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
